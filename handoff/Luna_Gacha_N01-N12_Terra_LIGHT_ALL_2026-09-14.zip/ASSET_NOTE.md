# Nカード軽量アセット版

GitHub / Codex 実装用に、N01〜N12の画像をPNGから高品質WebPへ変換した軽量版です。
画像のピクセル寸法は維持し、ファイル容量のみ大幅に削減しています。
実装時は `assets/N/*.webp` を使用してください。元PNGをリポジトリへ追加する必要はありません。

大カード/ミニカードの仕様・採用内容はREADME_TERRA.mdおよびDevelopment Masterに従ってください。
