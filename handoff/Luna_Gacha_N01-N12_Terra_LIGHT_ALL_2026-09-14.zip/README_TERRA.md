# Luna Gacha — N01–N12 Terra Implementation Pack

## 目的
既存の「ルナ🌙ガチャ」プロジェクトへ、確定済みNレア12種（N01〜N12）の大カード／ミニカード画像を実装する。

## 変更禁止の確定仕様・境界
- 既存UI・既存機能・既存カード挙動を壊さない。
- Nレアは全12種。`assets/N/` の画像を正本として使用する。
- 大カードとミニカードは別画像。勝手なトリミングや再生成で代用しない。
- 大カード基準: 1374×1145（横長、約1.20:1）。ミニカード基準: 1024×1536（縦2:3）。素材に微小な生成時サイズ差がある場合は、見た目を崩さず既存UI側で扱う。
- Nレア表示は `N ☆`。余計な星を追加しない。
- 確定済みのルナ、カード名、画像、既存世界観を変更しない。
- 不要なリファクタリングや広範囲な仕様変更をしない。
- 詳細な既存仕様・プロジェクト方針は `docs/Luna_Gacha_Development_Master_v7.md` を参照。ただし本パックの確定事項と競合する古い記述がある場合は本READMEを優先する。

## Nカード対応表
| ID | タイトル | large | mini |
|---|---|---|---|
| N01 | ねむい | N01_nemui_large.png | N01_nemui_mini.png |
| N02 | おやつ | N02_oyatsu_large.png | N02_oyatsu_mini.png |
| N03 | ごろごろ | N03_gorogoro_large.png | N03_gorogoro_mini.png |
| N04 | 通常運転 | N04_tsujo_unten_large.png | N04_tsujo_unten_mini.png |
| N05 | 鏡 | N05_kagami_large.png | N05_kagami_mini.png |
| N06 | お買い物 | N06_kaimono_large.png | N06_kaimono_mini.png |
| N07 | 寝ぐせ | N07_neguse_large.png | N07_neguse_mini.png |
| N08 | 忘れもの | N08_wasuremono_large.png | N08_wasuremono_mini.png |
| N09 | お片付け | N09_okataduke_large.png | N09_okataduke_mini.png |
| N10 | 夜ふかし | N10_yofukashi_large.png | N10_yofukashi_mini.png |
| N11 | 勉強 | N11_benkyo_large.png | N11_benkyo_mini.png |
| N12 | 伸びる | N12_nobiru_large.png | N12_nobiru_mini.png |

## 完成条件
1. N01〜N12が既存カード一覧／ガチャ表示の想定箇所で利用できる。
2. 一覧では各カードのmini画像、詳細／拡大表示では対応するlarge画像が正しく使われる。
3. ID・タイトル・画像の対応に取り違えがない。
4. 既存UIの比率・レイアウト・カード切替／フリップ等の既存挙動を維持する。
5. 実装後にアプリを起動し、N01〜N12を実画面で確認する。
6. 画像切れ、縦横比崩れ、誤画像、コンソールエラー等があれば修正する。
7. 関連する既存テスト／ビルドチェックを実行し、今回の変更による回帰がないことを確認する。
8. 実装→起動確認→結果確認→必要な修正→関連テストまで完了してから終了する。途中の不要な確認で止めない。

## Terraへの作業方針
実装方法・変更ファイルは既存コードを調査して判断してよい。まず既存のカードデータ構造と画像配置規則を確認し、それに合わせて最小限の変更でN01〜N12を追加すること。
